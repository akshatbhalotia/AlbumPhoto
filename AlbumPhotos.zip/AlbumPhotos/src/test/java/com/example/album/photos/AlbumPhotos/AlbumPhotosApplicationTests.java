package com.example.album.photos.AlbumPhotos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlbumPhotosApplicationTests {

	@Test
	void contextLoads() {
	}

}
