package com.example.album.photos.AlbumPhotos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlbumPhotosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlbumPhotosApplication.class, args);
	}

}
